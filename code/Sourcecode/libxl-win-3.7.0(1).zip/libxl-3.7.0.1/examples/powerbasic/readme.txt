These examples show how to use LibXL(http://www.libxl.com) with PowerBasic (https://www.powerbasic.com)

LibXL usage in PowerBasic
*Place all the inc files in your project directory
*For projects that are using unicode strings include libxlw.inc, otherwise use libxl.inc
*Call the functions using the C API found in the documentation.
*Copy the libxl.dll file from the bin directory to the project folder as it is needed to run the executable and should be packaged with the runtime file.

